<?php
namespace app\forms;

use std, gui, framework, app;


class VKWEB extends AbstractForm
{

}