<?php
namespace app\forms;

use std, gui, framework, app;


class desktop extends AbstractForm
{

    /**
     * @event mediaView.construct 
     */
    function doMediaViewConstruct(UXEvent $e = null)
    {    
        
    }



}
