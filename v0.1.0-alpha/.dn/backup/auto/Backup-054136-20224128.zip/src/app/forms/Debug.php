<?php
namespace app\forms;

use std, gui, framework, app;


class Debug extends AbstractForm
{

}