<?php
namespace app\modules;

use std, gui, framework, app;


class MainModule extends AbstractModule
{

    /**
     * @event player.construct 
     */
    function doPlayerConstruct(ScriptEvent $e = null)
    {    
        
    }


}
