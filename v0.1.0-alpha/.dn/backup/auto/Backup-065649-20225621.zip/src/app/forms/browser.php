<?php
namespace app\forms;

use std, gui, framework, app;


class browser extends AbstractForm
{

    /**
     * @event button.click-Left 
     */
    function doButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event browser.running 
     */
    function doBrowserRunning(UXEvent $e = null)
    {    
        
    }

    /**
     * @event browser.load 
     */
    function doBrowserLoad(UXEvent $e = null)
    {    
        
    }

    /**
     * @event browser.fail 
     */
    function doBrowserFail(UXEvent $e = null)
    {    
        
    }

    /**
     * @event construct 
     */
    function doConstruct(UXEvent $e = null)
    {    
        
    }

}
