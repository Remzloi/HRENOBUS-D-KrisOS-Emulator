<?php
namespace app\forms;

use std, gui, framework, app;


class MainForm extends AbstractForm
{

    /**
     * @event construct 
     */
    function doConstruct(UXEvent $e = null)
    {    
        
    }

    /**
     * @event imageAlt.construct 
     */
    function doImageAltConstruct(UXEvent $e = null)
    {    
        
    }

}
