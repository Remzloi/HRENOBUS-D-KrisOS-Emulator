<?php
namespace app\forms;

use std, gui, framework, app;


class desktop extends AbstractForm
{

    /**
     * @event imageAlt.click-Left 
     */
    function doImageAltClickLeft(UXMouseEvent $e = null)
    {    
        
    }

}
